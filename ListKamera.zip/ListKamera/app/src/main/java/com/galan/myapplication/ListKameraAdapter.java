package com.galan.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class ListKameraAdapter extends RecyclerView.Adapter<ListKameraAdapter.ListViewHolder> {
    private ArrayList<Kamera> listKamera;

    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback){
        this.onItemClickCallback = onItemClickCallback;
    }
    public ListKameraAdapter(ArrayList<Kamera> list){
        this.listKamera = list;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row_kamera, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListKameraAdapter.ListViewHolder holder, int position) {
        Kamera kamera = listKamera.get(position);
        holder.tvKamera.setText(kamera.getName());
        holder.tvDetail.setText(kamera.getDetail());
        Glide.with(holder.itemView.getContext())
                .load(kamera.getPhoto())
                .apply(new RequestOptions().override(60,55))
                .into(holder.Gambar);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onItemClicked(listKamera.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return listKamera.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {
        TextView tvKamera, tvDetail;
        ImageView Gambar;

        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            tvKamera = itemView.findViewById(R.id.tv_name);
            tvDetail = itemView.findViewById(R.id.tv_detail);
            Gambar = itemView.findViewById(R.id.img_kamera);
        }
    }
    public interface OnItemClickCallback {
        void onItemClicked(Kamera data);
    }
}
