package com.galan.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvKamera;
    private ArrayList<Kamera> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        rvKamera = findViewById(R.id.rv_kamera);
        rvKamera.setHasFixedSize(true);

        list.addAll(KameraData.getListData());
        showRecyclerList();
    }

    private void showRecyclerList() {
        rvKamera.setLayoutManager(new LinearLayoutManager(this));
        ListKameraAdapter listKameraAdapter = new ListKameraAdapter(list);
        rvKamera.setAdapter(listKameraAdapter);

        listKameraAdapter.setOnItemClickCallback(new ListKameraAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Kamera data) {
                showSelectedData(data);
            }
        });
    }

    public void showSelectedData(Kamera l) {
        Intent detail = new Intent(MainActivity.this, DetailKamera.class);
        detail.putExtra(DetailKamera.EXTRA_NAMAKAMERA, l.getName());
        detail.putExtra(DetailKamera.EXTRA_BERDIRI, l.getBerdiri());
        detail.putExtra(DetailKamera.EXTRA_PENGERTIAN, l.getDetail());
        detail.putExtra(DetailKamera.EXTRA_SEJARAH, l.getSejarah());
        detail.putExtra(DetailKamera.EXTRA_IMG, l.getPhoto());
        startActivity(detail);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent about = new Intent(MainActivity.this, About.class);
        startActivity(about);
        return super.onOptionsItemSelected(item);
    }
}